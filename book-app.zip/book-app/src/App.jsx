import './App.css'
import Book from './components/Book'
import Navbar from './components/Navbar'

function App() {

  return (
    <div className="App">
      <Navbar />
      <Book title={"First Book"} price={400} img="https://hatrabbits.com/wp-content/uploads/2017/01/random.jpg"/>
      <Book title={"Second Book"} price={600} img={"https://www.shutterstock.com/shutterstock/photos/2286554497/display_1500/stock-photo-random-pictures-cute-and-funny-2286554497.jpg"}/>
      <Book title={"Third Book"} price={800} img={"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1hZxkl7aLUy170veFH3FI9uDbkqoSBjMY2A&s"}/>
      <Book title={"Fourth Book"} price={1000} img={"https://images.unsplash.com/photo-1494253109108-2e30c049369b?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cmFuZG9tfGVufDB8fDB8fHww&fm=jpg&q=60&w=3000"}/>
    </div>
  )
}

export default App