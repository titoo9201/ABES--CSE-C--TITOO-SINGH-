import React from 'react'

function Navbar() {
  return (
    <nav className='Navbar' style={{
      background: '#2d3748',
      padding: '1rem',
      color: '#fff',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    }}>
      <ul style={{
        display: 'flex',
        listStyle: 'none',
        margin: 0,
        padding: 0,
        alignItems: 'center',
        gap: '2rem',
        fontSize: '1.1rem'
      }}>
        <li style={{ fontWeight: 'bold', fontSize: '1.3rem' }}>Book App</li>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
    </nav>
  )
}

export default Navbar