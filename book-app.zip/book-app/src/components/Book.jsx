import React from 'react'
import './styles/Book.css'
import Count from './Count'

function Book({title, price, img}) {
  return (
    <div className='Book'>
        <img src={img} alt="" />
        <p>{title}</p>
        <p>Rs. {price}</p>
        <Count />
    </div>
  )
}

export default Book