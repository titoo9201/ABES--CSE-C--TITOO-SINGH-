import React from 'react'
import "./styles/Count.css"

function Count() {
  const [count, setCount] = React.useState(0);
  return (
    <div className='main'>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <button
          onClick={() => setCount(count - 1)}
          className='dec-button'
        >-</button>
        <span
          className='span'
        >{count}</span>
        <button
          onClick={() => setCount(count + 1)}
          className='inc-button'
        >+</button>
      </div>
    </div>
  )
}

export default Count